//
//  ViewController.swift
//  pickerViewCity
//
//  Created by Mac on 4/25/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController , UIPickerViewDataSource,UIPickerViewDelegate{
   
    var aryState = ["Gujarat","Maharashtra","Rajsthan","Kerala","Tamilnadu"]
    var gujCity = ["Ahemdabad","Rajkot","Surat","bhavnagar"]

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
    }
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 2
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if component == 0
         { return aryState.count
            
        }
            else {
                return gujCity.count
        }
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        if component == 0 {return aryState[row]}
            
        else 
        { return gujCity[row]}
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        print(component)
        
        
    }

}

